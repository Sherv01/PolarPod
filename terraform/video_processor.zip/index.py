import json
import boto3
import subprocess
import os

# Initialize S3 client
s3 = boto3.client('s3')
BUCKET_NAME = "brainrot-media-bucket"
client = boto3.client(
    's3',
    aws_access_key_id="AKIA5CBGTIAIT6INCPGA",
    aws_secret_access_key="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"
)
os.system("yum install ffmpeg -y")

def handler(event, context):
    print("c1")
    # Parse the request body
    video_key = 'input/video.mp4'  # S3 key for the input video
    audio_key = 'input/audio.mp3'  # S3 key for the input audio

    # Paths for temporary storage
    video_path = '/tmp/video.mp4'
    audio_path = '/tmp/audio.mp3'
    output_path = '/tmp/output_video.mp4'
    print("c2")

    # Download video and audio from S3
    client.download_file(BUCKET_NAME, video_key, video_path)
    client.download_file(BUCKET_NAME, audio_key, audio_path)
    print("c3")

    # Process video with FFmpeg
    # subprocess.run([
    #     'ffmpeg', '-i', video_path,
    #     '-i', audio_path,
    #     '-vf', 'crop=in_h*9/16:in_h',  # Crop to phone aspect ratio
    #     '-c:v', 'libx264', '-c:a', 'aac',
    #     '-map', '0:v:0', '-map', '1:a:0',
    #     output_path
    # ], check=True)
    # print("c4")

    # Upload processed video back to S3
    output_key = 'input/output_video.mp4'
    s3.upload_file(video_path, BUCKET_NAME, output_key)

    # Generate URL for the processed video
    video_url = f'https://{BUCKET_NAME}.s3.amazonaws.com/{output_key}'

    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Video processed successfully',
            'video_url': video_url
        }),
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': '*'
        }
    }
